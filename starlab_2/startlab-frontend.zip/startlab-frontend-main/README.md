# Стартлаб — демо-страница (React + Tailwind)

## Быстрый старт
```bash
npm i
npm run dev
```

## Стек
- React + Vite
- TailwindCSS

SVG логотипы лежат в `src/assets/`.
Все остальные изображения заменены на заглушки.
